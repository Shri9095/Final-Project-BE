#pragma once

#include "Arduino.h"
#include "SPIFFS.h"

void esp32_setup_peripherals(void);